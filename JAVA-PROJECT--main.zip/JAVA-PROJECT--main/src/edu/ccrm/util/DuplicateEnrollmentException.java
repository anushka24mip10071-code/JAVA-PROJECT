package edu.ccrm.util;

public class DuplicateEnrollmentException extends CCRMException {
    public DuplicateEnrollmentException(String message) {
        super(message);
    }
}