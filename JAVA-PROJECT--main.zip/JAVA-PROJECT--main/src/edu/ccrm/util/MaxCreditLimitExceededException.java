package edu.ccrm.util;

public class MaxCreditLimitExceededException extends CCRMException {
    public MaxCreditLimitExceededException(String message) {
        super(message);
    }
}